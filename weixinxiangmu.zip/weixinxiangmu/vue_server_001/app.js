//app.js
//1:加载模块 express pool.js
const express = require("express");
const pool = require("./pool");
//2:创建服务器端对象
var app = express();
//3:监听 3000
app.listen(3000);
//4:指定静态目录  public 
app.use(express.static("public"));
//5:加载跨域访问模块
const cors = require("cors");
//6:配置跨域访问模块 那个域名跨域访问允许
//  脚手架8080允许
//origin      允许跨域访问域名列表
//credentials 跨域访问保存session id
app.use(cors({
  origin:["http://127.0.0.1:8080",
  "http://localhost:8080"],
  credentials:true
}));
//6.1:下载express-session并且配置
  const session = require("express-session");
  app.use(session({
    secret:"128位随机字符",
    resave:false,
    saveUninitialized:true,
    cookie:{
      maxAge:1000 * 60 * 60 *8
    }
  }));
//7:加载第三方模块 body-parser
//body-parser 针对post请求处理请求参数
//如果配置成功 req.body..
const bodyParser = require("body-parser");
//8:配置对特殊 json是否是自动转换 不转换
app.use(bodyParser.urlencoded({extended:false}))




//微信小程序
//vue_server_00
//功能一：给小程序首页返回轮播数据
app.get("/image",(req,res)=>{
  var rows =[{code:1,img_url:"http://127.0.0.1:3000/img/banner1.jpg"},
   {code:2,img_url:"http://127.0.0.1:3000/img/banner2.jpg"},
   {code:3,img_url:"http://127.0.0.1:3000/img/banner3.jpg"},
   {code:4,img_url:"http://127.0.0.1:3000/img/banner4.jpg"},
   {code:4,img_url:"http://127.0.0.1:3000/img/banner5.jpg"},
 ] ;
 res.send(rows);
 })
 //3:创建js对象 图片编号  图片地址
 //4:返回

//功能二:婚纱摄影图片
app.get("/img",(req,res)=>{
  var rows =[
    {id:1, img_url:"http://127.0.0.1:3000/img/a1.jpg"},
    {id:2, img_url:"http://127.0.0.1:3000/img/a2.jpg"},
    {id:3, img_url:"http://127.0.0.1:3000/img/a3.jpg"},
    {id:4, img_url:"http://127.0.0.1:3000/img/a4.jpg"}
];
res.send(rows);
})

//功能三:亲子摄影图片
app.get("/imgages",(req,res)=>{
  var rows =[
    {id:1, img_url:"http://127.0.0.1:3000/img/b1.jpg"},
    {id:2, img_url:"http://127.0.0.1:3000/img/b2.jpg"},
    {id:3, img_url:"http://127.0.0.1:3000/img/b3.jpg"},
    {id:4, img_url:"http://127.0.0.1:3000/img/b4.jpg"}
];
res.send(rows);
})


//功能三:个人写真图片
app.get("/imgages1",(req,res)=>{
  var rows =[
    {id:1, img_url:"http://127.0.0.1:3000/img/c1.jpg"},
    {id:2, img_url:"http://127.0.0.1:3000/img/c2.jpg"},
    {id:3, img_url:"http://127.0.0.1:3000/img/c3.jpg"},
    {id:4, img_url:"http://127.0.0.1:3000/img/c4.jpg"}
];
res.send(rows);
})
 

//功能三:全家福写真图片
app.get("/imgages2",(req,res)=>{
  var rows =[
    {id:1, img_url:"http://127.0.0.1:3000/img/d1.jpg"},
    {id:2, img_url:"http://127.0.0.1:3000/img/d2.jpg"},
    {id:3, img_url:"http://127.0.0.1:3000/img/d3.jpg"},
    {id:4, img_url:"http://127.0.0.1:3000/img/d4.jpg"}
];
res.send(rows);
})







